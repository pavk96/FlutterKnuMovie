import 'package:flutter/material.dart';

Color kPrimaryColor = Color(0xFFFE4350);

enum Option { LogIn, SignUp }
