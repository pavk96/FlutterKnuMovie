import 'package:flutter/material.dart';

class LandingPage extends StatelessWidget {
  List<Widget> pageChildren(double width) {
    return <Widget>[
      Container(
        width: width,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              "KNU \nMovies",
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 40.0,
                  color: Colors.white),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 20.0),
              child: Text(
                "최선을 다해 영화를 한땀한땀 만들었습니다",
                style: TextStyle(fontSize: 16.0, color: Colors.white),
              ),
            ),
            Row(
              children: <Widget>[
                Container(
                  color: Colors.white,
                  width: width,
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.only(left: 20),
                      child: TextField(
                        decoration: InputDecoration(
                            hintText: "Search", border: InputBorder.none),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      Image.asset(
        "assets/images/knuknu.png",
        width: width,
        height: 300,
      )
    ];
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      //제약조건에 따라 내용물 결정
      builder: (context, constraints) {
        if (constraints.maxWidth > 800) {
          return Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: pageChildren(constraints.biggest.width / 2),
          );
        } else {
          return Column(children: pageChildren(constraints.biggest.width));
        }
      },
    );
  }
}
